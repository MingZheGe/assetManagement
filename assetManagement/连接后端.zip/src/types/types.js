export const categoryes = {
    food: {
      icon: 'shiwu',
      name: '餐饮',
    },
    life: {
      icon: 'shenghuojiaofei',
      name: '生活缴费',
    },
    shopping: {
      icon: 'gouwudai',
      name: '购物',
    },
    transport: {
      icon: 'jiaotongfei',
      name: '交通',
    },
    other: {
      icon: 'ico_e_advice',
      name: '其他',
    },
    houseLoan: {
      icon: 'ico_e_advice',
      name: '住房性贷款',
    },
  }


