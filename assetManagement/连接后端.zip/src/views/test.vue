<template>
  <div class="box">
    
  <el-aside width="200px" class="aside">
    <Aside :menu-item="4"></Aside>
  </el-aside>
  <el-main>
    <div ref="main" class="echarts" style="width: 100%; height: 800px;"></div>
    <Topbar title="统计" />
    <div class="container">
      <div class="flex gap-2 items-end">
        <div class="text-xl color-green">
          支出
        </div>
        <div>收入</div>
        <div>对比</div>
      </div>
      <div class="date flex justify-center">
        <div class="date-item">5月</div>
        <div class="date-item">6月</div>
        <div class="date-item">7月</div>
        <div class="date-item">8月</div>
        <div class="date-item">9月</div>
        <button class="month-select">月</button>
      </div>
      

      <div class="expenditure-top">
        <div class="base-title">
          支出排行
        </div>
        <div class="item-container">
          
          <div v-for="(i, idx) in categoryValue" :key="idx" class="item">
            <div class="icon">
              <svg class="icon-font" aria-hidden="true">
                <use :xlink:href="`#icon-${i.icon}`" />
              </svg>
            </div>
            <div class="item-right">
              <div class="base-title">
                {{ i.name }}&nbsp;&nbsp;{{ i.value }}%
              </div>
              <div class="process-bar">
                <div class="bar" :style="{ width: i.value + '%' }">
                  <div></div>
                </div>
              </div>
            </div>
          </div>
      
        </div>
      </div>
    </div>
    </el-main>
  </div>
</template>

<script>
import * as echarts from 'echarts'
import {categoryes} from '../types/types'//只导入特定的属性，变量
import dayjs from 'dayjs'
import Aside from "../components/Aside2.vue";
import Topbar from "../components/Topbar.vue";
import InfoCard from "../components/InfoCard.vue";
import BillContainer from "../components/BillContainer.vue";
import { amountToArray } from '../compute/amountFormat'
import { sumCount } from '../compute/amountFormat'

export default {
  components: {
  Aside,
  Topbar,
  InfoCard,
  BillContainer
},
  data() {
    return {
      week: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
      income: '',
      expend: '',
      myChart: null, // 初始化为null
      categoryValue :[
{
  name: '餐饮',
  value: 30, // 假设占比为 30%
  icon: 'restaurant', // 假设使用名为 "restaurant" 的图标
},
{
  name: '购物',
  value: 20, // 假设占比为 20%
  icon: 'shopping', // 假设使用名为 "shopping" 的图标
},
// 其他项目
],
    }
  },
  computed: {
    totalExpenses() {
      const res = this.$store.state.mainStore.recordList.usually.filter((r) => r.type === 'expend')
      return res.reduce((acc, cur) => acc + cur.amount, 0)
    },
    /*
    categoryValue() {
      const res = []
      for (const k in categoryes) {
        const amount = this.$store.state.mainStore.recordList.usually.reduce((count, item) => {
          if (item.category === k) count += item.amount
          return count
        }, 0)
        res.push({
          name: categoryes[k].name,
          value: Math.floor((amount / this.totalExpenses) * 100),
          icon: categoryes[k].icon,
        })
      }
      return res
    },
    */
  },
  methods: {
    init() {
      /*
     const option = {
  legend: {
    top: 'bottom'
  },
  toolbox: {
    show: true,
    feature: {
      mark: { show: true },
      dataView: { show: true, readOnly: false },
      restore: { show: true },
      saveAsImage: { show: true }
    }
  },
  series: [
    {
      name: 'Nightingale Chart',
      type: 'pie',
      radius: [50, 250],
      center: ['50%', '50%'],
      roseType: 'area',
      itemStyle: {
        borderRadius: 8
      },
      data: [
        { value: 40, name: 'rose 1' },
        { value: 38, name: 'rose 2' },
        { value: 32, name: 'rose 3' },
        { value: 30, name: 'rose 4' },
        { value: 28, name: 'rose 5' },
        { value: 26, name: 'rose 6' },
        { value: 22, name: 'rose 7' },
        { value: 18, name: 'rose 8' }
      ]
    }
  ]
};
*/
 const option = {
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "cross",
            label: {
              backgroundColor: "#6a7985",
            },
          },
        },
        xAxis: {
          data: [
            "1月",
            "2月",
            "4月",
            "5月",
            "6月",
            "1月",
            "2月",
            "4月",
            "5月",
            "6月",
          ],
          boundaryGap: false,
        },
        yAxis: {
          show: false,
        },
        series: [
          {
            name: "折线1", // 第一条折线的名称
            data: [100, 200, 160, 80, 300, 100, 200, 160, 80, 300],
            type: "line",
            smooth: true,
            lineStyle: {
              width: 0,
            },
            showSymbol: false,
            areaStyle: {
              opacity: 0.8,
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "rgb(128, 255, 165)",
                },
                {
                  offset: 1,
                  color: "rgb(1, 191, 236)",
                },
              ]),
            },
          },

          {
            name: "折线2", // 第二条折线的名称
      data: [150, 120, 200, 120, 250, 180, 220, 180, 170, 220],
            type: "line",
            smooth: true,
            lineStyle: {
              width: 0,
            },
            showSymbol: false,
            areaStyle: {
              opacity: 0.8,
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
            offset: 0,
            color: "rgb(255, 128, 165)",
          },
          {
            offset: 1,
            color: "rgb(191, 1, 236)",
          },
              ]),
            },
          },
        ],
      }
     // this.$nextTick(() => {
      // 在 DOM 渲染完成后初始化 ECharts
      this.myChart = echarts.init(this.$refs.main)
      // 其它初始化代码...
    //})
      this.myChart.setOption(option)
    },
  },
  mounted() {
    this.init()
  },
}
</script>

<style scoped lang="less">
@import '../styles/common.less';

.box{
//background: linear-gradient(30deg,#baebe7, #2a7c76);
background: linear-gradient(30deg,#baebe7, #14c4b8);
//background:url("../assets/image/sbpk.jpg");
background-size: 100% 15rem;
background-repeat: no-repeat;
padding-bottom: 2rem;
box-sizing: border-box;
display: flex;
}
.container {
  padding: 1rem;

  .date {
    margin: 1rem 0;
    display: flex;
    font-size: small;
    justify-content: space-evenly;

    .date-item {
      color: @gray-2;
      padding: .3rem .8rem;
      border-radius: .6rem;
      background-color: rgb(237, 250, 248);
    }

    .month-select {
      color: @primary-0;
    }
  }

  .echarts {
    width: 100%;
    height: 200px;
  }

  .expenditure-top {
    background-color: #fff;
    border-radius: .2rem;
    padding: 1em;

    .item-container {
      .item {
        display: flex;
        align-items: center;
        padding-bottom: .4rem;
        gap: .5rem;

        .icon {
          border: .5rem;
          background-color: @primary-8;
          border-radius: .5rem;
        }

        .item-right {
          flex: 1;
        }

        .process-bar {
          position: relative;
          width: 100%;
          height: 10px;
          background-color: @primary-3;
          border-radius: 5px;

          .bar {
            height: 100%;
            div {
              width: 100%;
              height: 100%;
              border-radius: 5px;
              background-color: @primary-1;
              animation: load-bar .5s ease-out;
            }
          }

          @keyframes load-bar {
            0% {
              width: 0;
            }

            100% {
              width: 100%;
            }
          }
        }
      }
    }
  }
}
</style>
