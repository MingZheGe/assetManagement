
<template>
  <el-drawer
    :title="descriptionTitle"
    :visible.sync="showDrawer"
    direction="rtl"
    :size="this.drawerSize"
  >
    <!--
   <el-table :data="gridData">
      <el-table-column property="date" label="日期" width="150"></el-table-column>
      <el-table-column property="name" label="姓名" width="200"></el-table-column>
      <el-table-column property="address" label="地址"></el-table-column>
    </el-table>
  -->
    <div v-if="type === 'bill'" style="margin-top: 30%; padding: 1rem">
      <el-descriptions :column="1" border>
        <el-descriptions-item label="账单类型">收入</el-descriptions-item>
        <el-descriptions-item label="账单金额">500.32</el-descriptions-item>
        <el-descriptions-item label="类型">餐饮</el-descriptions-item>
        <el-descriptions-item label="创建账单日期"
          >2023-11-08</el-descriptions-item
        >
        <el-descriptions-item label="备注" :span="2">午餐</el-descriptions-item>
      </el-descriptions>
      <div style="display: flex; justify-content: center; margin-top: 20px">
        <el-button type="danger" round @click="deleteBill">删除</el-button>
      </div>
    </div>

    <div v-if="type === 'loan'" style="padding: 1rem">
      <el-descriptions :column="1" border>
        <el-descriptions-item label="每月支付本息"
          >986.52元</el-descriptions-item
        >
        <el-descriptions-item label="累计支付利息"
          >13436元</el-descriptions-item
        >
        <el-descriptions-item label="累计还款总额"
          >36315元</el-descriptions-item
        >

        <el-descriptions-item label="每月支付本息"
          >986.52元</el-descriptions-item
        >
        <el-descriptions-item label="累计支付利息"
          >13436元</el-descriptions-item
        >
        <el-descriptions-item label="累计还款总额"
          >36315元</el-descriptions-item
        >
        <el-descriptions-item label="贷款类型"
          >个人住房性贷款</el-descriptions-item
        >
        <el-descriptions-item label="贷款金额">30000元</el-descriptions-item>
        <el-descriptions-item label="贷款期限">1年</el-descriptions-item>
        <el-descriptions-item label="还款方式"
          >等额本息还款</el-descriptions-item
        >
        <el-descriptions-item label="年化利率">3.45%</el-descriptions-item>
        <el-descriptions-item label="贷款日期">2023-11-08</el-descriptions-item>
      </el-descriptions>
      <div style="display: flex; justify-content: center; margin-top: 20px">
        <el-button type="danger" round @click="deleteBill">删除</el-button>
      </div>
    </div>

    <div v-if="type === 'stock'" style="padding: 1rem">
      <div
        style="
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          margin-bottom: 2rem;
        "
      >
        <div><span>中国长城</span><span>000066</span></div>
        <div>今日盈亏</div>
        <div>+2685.00</div>
        <div>持仓盈亏</div>
        <div>+2685.00</div>
      </div>
      <div style="border: 1px solid #000; padding: 1rem; display: flex">
        <div class="info">
          <div class="name">
            <span>10.95</span
            ><!---<span style="color: rgb(162, 162, 167); font-weight: normal; margin-left: 10px">{{ data.remark || this.label }}</span>-->
          </div>
          <div>+1.86%</div>
        </div>
        <div class="ooo">
          <div>
            <span>最高价</span><span>10.98</span>
            <div style="margin-top: 1rem;"><span>最低价</span><span>10.66</span></div>
          </div>
          <div><span>开盘价</span><span>10.77</span>
            <div style="margin-top: 1rem;"><span>换手率</span><span>0.84%</span></div>
          </div>
          <div><span>成交量</span><span>26.28万手</span>
            <div style="margin-top: 1rem;"><span>成交额</span><span>2.85亿</span></div>
          </div>
        </div>
    

      </div>
    </div>
  </el-drawer>
</template>
      
      
      <script>
export default {
  props: {
    ifshowDrawer: Boolean,
    type: String,
  },
  watch: {
    ifshowDrawer(newValue, oldValue) {
      if (newValue !== oldValue) {
        console.log("向父组件传递改变的值原来", oldValue);
        console.log("向父组件传递改变的值现在", newValue);
        if (this.type == "stock") this.drawerSize = "60%";
        this.showDrawer = newValue;
        //this.$emit('dialog-form-visible-changed', newValue);
      } else {
        console.log("111");
      }
    },
    showDrawer(newValue, oldValue) {
      if (newValue !== oldValue) {
        console.log("drawer原来", oldValue);
        console.log("drawer现在", newValue);
        this.$emit("drawerFalse", newValue);
      }
    },
  },
  data() {
    return {
      showDrawer: false,
      drawerSize: "30%",
      dialog: false,
      loading: false,
      gridData: [
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄",
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄",
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄",
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄",
        },
      ],

      timer: null,
    };
  },
  methods: {
    handleClose(done) {
      if (this.loading) {
        return;
      }
      this.$confirm("确定要提交表单吗？")
        .then((_) => {
          this.loading = true;
          this.timer = setTimeout(() => {
            done();
            // 动画关闭需要一定的时间
            setTimeout(() => {
              this.loading = false;
            }, 400);
          }, 2000);
        })
        .catch((_) => {});
    },
    deleteBill() {
      this.$message({
        message: "等着连",
        type: "warning",
      });
    },
    cancelForm() {
      this.loading = false;
      this.dialog = false;
      clearTimeout(this.timer);
    },
  },
  computed: {
    descriptionTitle() {
      return this.type === "loan"
        ? "贷款详情"
        : this.type === "bill"
        ? "账单详情"
        : this.type === "stock"
        ? "股票详情"
        : this.type === "fund"
        ? "基金详情"
        : "未知详情"; // 你可以根据需要添加更多类型
    },
  },
};
</script>
      
   <style lang="less" scoped>
@import "../styles/common.less";
/deep/.el-drawer__header {
  text-align: center;
  //background-color: #409EFF; /* 背景颜色 */
  color: #000000; /* 文字颜色 */
  font-size: 20px; /* 字体大小 */
  border-bottom: 1px solid #e0e0e0; /* 下边框线 */
}

.info {
  color: @gray-1;
  font-size: 20px;
  .name {
    font-size: 24px;
    color: @gray-10;
    font-weight: 600;
  }
}

.ooo{
    display: flex;
    width: 90%;
    //margin-left: 3rem;
    gap: 0.5rem;
    align-items:flex-start;
    justify-content: space-between;
    font-size: 0.8rem;
    color: #000;
    font-size: 1rem;
    color: #000;
    font-weight: bold;
    margin-left: 2rem;
  }
</style>
      