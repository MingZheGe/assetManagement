<template>
  <div id="app2">
    <div id="kline" ref="kline" style="width: 300px; height: 300px"></div>
    <span>111 </span>
  </div>
</template>

<script>
import HQChart from "hqchart";
// import HQChart from "node_modules/hqchart"
function DefaultData() {}

DefaultData.GetKLineOption = function () {
  let data = {
    Type: "历史K线图",

    //窗口指标
    Windows: [
      { Index: "MA", Modify: false, Change: false },
      { Index: "VOL", Modify: false, Change: false },
    ],

    IsShowCorssCursorInfo: true,

    //边框
    Border: {
      Left: 1,
      Right: 1, //右边间距
      Top: 25,
      Bottom: 25,
    },

    KLine: {
      Right: 1, //复权 0 不复权 1 前复权 2 后复权
      Period: 0, //周期: 0 日线 1 周线 2 月线 3 年线
      PageSize: 70,
      IsShowTooltip: true,
    },
  };

  return data;
};

export default {
  data() {
    var data = {
      Symbol: "600000.sh",
      KLine: {
        JSChart: null,
        Option: DefaultData.GetKLineOption(),
      },
    };

    return data;
  },

  created() {
    console.log(58)
  },

  mounted() {
    console.log(60)
    this.OnSize();

    window.onresize = () => {
      this.OnSize();
    };

    this.CreateKLineChart();
  },

  methods: {
    OnSize() {
      var chartHeight = window.innerHeight - 30;
      var chartWidth = window.innerWidth - 30;

      var kline = this.$refs.kline;
      kline.style.width = chartWidth + "px";
      kline.style.height = chartHeight + "px";
      if (this.KLine.JSChart) this.KLine.JSChart.OnSize();
    },

    CreateKLineChart() { //创建K线图
      if (this.KLine.JSChart) {
        return;
      }
      this.KLine.Option.Symbol = this.Symbol;
      let chart = HQChart.Chart.JSChart.Init(this.$refs.kline);
      chart.SetOption(this.KLine.Option);
      this.KLine.JSChart = chart;

      console.log(89, chart)
    },
  },
};
</script>