
<template>
  <div class="box">
 
  </div>
</template>
    
    
    <script>

export default {


  data() {
    return {
 
    };
  },
  methods: {},
};
</script>
    
 <style lang="less" scoped>
@import "../styles/common.less";
@import "../styles/common.css";
@import "../styles/main.css";


</style>
    