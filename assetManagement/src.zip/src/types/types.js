export const categoryes = {
    food: {
      icon: 'shiwu',
      name: '餐饮',
    },
    stock:{
      icon: 'Stocks',
      name:'股票'
    },
    life: {
      icon: 'shenghuojiaofei',
      name: '生活缴费',
    },
    shopping: {
      icon: 'gouwudai',
      name: '购物',
    },
    transport: {
      icon: 'jiaotongfei',
      name: '交通',
    },
    other: {
      icon: 'ico_e_advice',
      name: '其他',
    },
    houseLoan: {
      icon: 'cottage-house-style-realestate-building-rent-prope',
      name: '个人住房贷款',
    },
    carLoan: {
      icon: 'qiche',
      name: '个人汽车贷款',
    },
    businessLoan: {
      icon: 'jingyingcelve',
      name: '经营性贷款',
    },
    costLoan: {
      icon: 'xiaofei',
      name: '消费性贷款',
    },
    otherLoan: {
      icon: 'daikuan',
      name: '其他类贷款',
    },
  }


